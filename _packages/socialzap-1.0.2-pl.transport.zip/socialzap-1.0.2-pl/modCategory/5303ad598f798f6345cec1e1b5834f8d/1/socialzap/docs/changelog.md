Changelog for socialZap

socialZap 1.0.2
---------------------------------
+ Fix date of media on import

socialZap 1.0.1
---------------------------------
+ Add socialFeed migration script

socialZap 1.0.0
---------------------------------
+ Initial Version
