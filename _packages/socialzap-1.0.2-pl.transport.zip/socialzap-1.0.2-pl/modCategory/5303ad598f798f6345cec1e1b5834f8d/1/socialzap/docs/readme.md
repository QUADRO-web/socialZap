socialZap

Author: Jan Dähne <https://www.quadro-system.de>
Copyright 2024

Official Documentation: https://www.quadro-system.de/modx-extras/socialzap/

Bugs and Feature Requests: https://github.com:jdaehne/socialZap

Questions: http://forums.modx.com
