<?php
/**
 * @package socialzap
 */
class SocialZapItem extends xPDOSimpleObject {}
?>