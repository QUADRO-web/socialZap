Changelog for socialZap

socialZap 1.0.0
---------------------------------
+ Initial Version
