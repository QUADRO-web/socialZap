<?php
/**
 * Setting Lexicon Entries for socialzap
 *
 * @package socialzap
 * @subpackage lexicon
 */
$_lang['setting_socialzap.image_path'] = 'Bild-Pfad';
$_lang['setting_socialzap.image_path_desc'] = 'Speicherort für importierte Bilder.';
$_lang['setting_socialzap.secret'] = 'Secret';
$_lang['setting_socialzap.secret_desc'] = 'Autentifizierungscode für Zapier.';
$_lang['setting_socialzap.published'] = 'Neue Beiträge veröffentlichen';
$_lang['setting_socialzap.published_desc'] = 'Neu Beiträge automatisch veröffentlichen?';
